using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class CoinManager : MonoBehaviour
{
    public TextMeshProUGUI coinText;
    private int coinCount;
    public int yondeger;
    public GameObject YonButton;
    public CharSound charSound;
    private void Start()
    {
        yondeger = PlayerPrefs.GetInt("yonkontrol");
        if(yondeger==1)
        {
            YonButton.SetActive(true);
        }
        if (yondeger == 0)
        {
            YonButton.SetActive(false);
        }
        coinCount = PlayerPrefs.GetInt("CoinCount", 0);
        UpdateCoinText();
        
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Coin"))
        {
            charSound.audioSource.PlayOneShot(charSound.Coin);
            coinCount++;
            UpdateCoinText();
            other.gameObject.SetActive(false);
        }
        if (other.CompareTag("Coin5"))
        {
            charSound.audioSource.PlayOneShot(charSound.Coin);
            coinCount +=5;
            UpdateCoinText();
            other.gameObject.SetActive(false);
        }
    }

    private void OnDestroy()
    {
        PlayerPrefs.SetInt("CoinCount", coinCount);
    }

    private void UpdateCoinText()
    {
        coinText.text = coinCount.ToString();
    }
}
