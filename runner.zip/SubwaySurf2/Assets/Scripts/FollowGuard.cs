using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowGuard : MonoBehaviour
{
    
    public Animator guardAnimator;
    public Animator dogAnimator;
    public Transform Guard;
    public Transform Dog;
    public float curDis;
    
    public void Jump()
    {
        StartCoroutine(PlayAnim("Guard_jump", "Dog_jump"));
    }

    public void LeftDodge()
    {
        StartCoroutine(PlayAnim("Guard_dodgeLeft", "Dog_Run"));
    }
    public void RightDodge()
    {
        StartCoroutine(PlayAnim("Guard_dodgeRight", "Dog_Run"));
    }
    public void CaughtPlayer()
    {
        guardAnimator.Play("catch_1");
        dogAnimator.Play("catch");
        
    }

    public void HitMovingTrain()
    {
        StartCoroutine(PlayAnim("Guard_death_movingTrain", "Dog_death_movingTrain"));
    }
    public void Stumble()
    {
        StopAllCoroutines();
        StartCoroutine(PlayAnim("Guard_grap after", "Dog_Fast Run"));
    }
    private IEnumerator PlayAnim(string anim,string anim2)
    {
        yield return new WaitForSeconds(curDis / 5f);
        guardAnimator.Play(anim);
        dogAnimator.Play(anim2);
    }
    
    public void Follow(Vector3 pos,float speed)
    {
        Vector3 position = pos - Vector3.forward * curDis;
        Guard.position = Vector3.Lerp(Guard.position, position, Time.deltaTime * speed / curDis);
        Dog.position = Guard.position;
    }

}
