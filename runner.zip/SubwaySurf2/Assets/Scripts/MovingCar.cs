using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingCar : MonoBehaviour
{
    public float speed = 0f; // �leri hareket h�z�
    private Vector3 initialPosition; // Ba�lang�� konumu
    public bool enable = false;
   
    

    private void OnEnable()
    {
        // Ba�lang�� konumunu kaydet
        initialPosition = transform.position;

        // �leri y�nde hareketi ba�lat
        enable = true;
    }
   
    private void OnDisable()
    {
        // Ba�lang�� konumuna geri d�n
        transform.position = initialPosition;

        // H�z� s�f�rla
        GetComponent<Rigidbody>().velocity = Vector3.zero;
        enable = false;
        speed = 0f;
    }
    void Update()
    {
        if(enable=true)
        {
            GetComponent<Rigidbody>().velocity = transform.forward * speed;
        }
    }
}
