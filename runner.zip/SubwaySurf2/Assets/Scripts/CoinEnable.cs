using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinEnable : MonoBehaviour
{
    // Start is called before the first frame update
    private void ActivateChildObjectsWithTag(string tag, bool isActive)
    {
        ActivateChildObjectsWithTagRecursive(transform, tag, isActive);
    }

    private void ActivateChildObjectsWithTagRecursive(Transform parent, string tag, bool isActive)
    {
        // T�m �ocuk nesneleri dola�
        for (int i = 0; i < parent.childCount; i++)
        {
            Transform child = parent.GetChild(i);

            // E�er �ocuk nesne etiketle e�le�iyorsa, etkinle�tir/devre d��� b�rak
            if (child.CompareTag(tag))
            {
                child.gameObject.SetActive(isActive);
            }

            // �ocuk nesnenin alt nesnelerini de kontrol et
            ActivateChildObjectsWithTagRecursive(child, tag, isActive);
        }
    }

    private void OnEnable()
    {
        ActivateChildObjectsWithTag("Coin", true);
    }

    private void OnDisable()
    {
        ActivateChildObjectsWithTag("Coin", false);
    }
}
