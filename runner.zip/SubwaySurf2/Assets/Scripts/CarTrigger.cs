using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarTrigger : MonoBehaviour
{
    // Start is called before the first frame update
    public MovingCar Car1;
    public MovingCar Car2;
    public MovingCar Car3;
    public MovingCar Car4;
    public MovingCar Car5;
    public MovingCar Car6;
    public float carspeed;
    void Start()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            
            if (Car1 != null)
            {
                Car1.speed = carspeed;
            }
            if (Car2 != null)
            {
                Car2.speed = carspeed;
            }
            if (Car3 != null)
            {
                Car3.speed = carspeed;
            }
            if (Car4 != null)
            {
                Car4.speed = carspeed;
            }
            if (Car5 != null)
            {
                Car5.speed = carspeed;
            }
            if (Car6 != null)
            {
                Car6.speed = carspeed;
            }
        }
        
    }
}
