using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Score : MonoBehaviour
{
    public TMP_Text scoreText;
    public TMP_Text bestScoreText;
    public Transform character;

    private float score;
    private float multiplier;
    private float bestScore;
    private bool isScoreMultiple = false;
    private float previousPositionZ;
    private float hizTutucu;
    private bool isPaused = false;

    public Sprite pauseSprite;
    public Sprite resumeSprite;
    public Sprite MusicSprite;
    public Sprite MuteSprite;
    public CharMove characterMove;
    public Button pause;
    public Button music;
    public AudioSource audioSourceAmbians;
    private bool isStopMusic = false;
    private void Start()
    {
        if (character != null)
        {
            score = 0f;
            multiplier = 1.0f;
            bestScore = PlayerPrefs.GetFloat("BestScore", 0f);

            previousPositionZ = character.position.z;

            UpdateScoreText();
            UpdateBestScoreText();
        }
    }

    private void Update()
    {
        if (character != null)
        {
            float distanceTraveled = character.position.z - previousPositionZ;
            IncreaseScore(distanceTraveled);
            previousPositionZ = character.position.z;
        }
        if (scoreText != null && characterMove != null && character != null && bestScoreText != null)
        {
            if (Convert.ToInt32(scoreText.text) % 100 == 0 )
            {
                if (!isScoreMultiple)
                {
                    KarakteriHizlandir();
                    isScoreMultiple = true;
                }
            }
            else
            {
                isScoreMultiple = false;
            }
        }
    }

    public void TogglePause()
    {
        if (isPaused)
        {
            ResumeGame();
        }
        else
        {
            PauseGame();
        }
    }
    public void ToggleMusic()
    {
        if (isStopMusic)
        {
            ResumeMusic();
        }
        else
        {
            MuteMusic();
        }
    }
    public void Menu()
    {
        SceneManager.LoadScene("Menu");
    }

    public void TekrarOyna()
    {
        SceneManager.LoadScene("SampleScene");
    }
    private void PauseGame()
    {
        Time.timeScale = 0f; // Zaman� durdur
        isPaused = true;
        characterMove.CanInput = false;
        pause.image.sprite = resumeSprite;
        // �stedi�iniz di�er pause i�lemlerini ger�ekle�tirin (UI g�r�n�rl���, ses duraklatma vb.)
    }

    private void ResumeGame()
    {
        Time.timeScale = 1f; // Zaman� devam ettir
        isPaused = false;
        characterMove.CanInput = true;
        pause.image.sprite = pauseSprite;
        // �stedi�iniz di�er devam ettirme i�lemlerini ger�ekle�tirin (UI gizleme, ses devam ettirme vb.)
    }

    private void ResumeMusic()
    {
        audioSourceAmbians.mute = false;
        isStopMusic = false;
        music.image.sprite = MusicSprite;

    }
    private void MuteMusic()
    {
        audioSourceAmbians.mute = true;
        isStopMusic = true;
        music.image.sprite = MuteSprite;

    }

    private void UpdateScoreText()
    {
        scoreText.text = score.ToString("F0");
        if (score > bestScore)
        {
            scoreText.color = Color.green;
        }
        else
        {
            scoreText.color = Color.white;
        }

        
    }

    private void UpdateBestScoreText()
    {
        bestScoreText.text =  bestScore.ToString("F0");
    }

    public void IncreaseScore(float distance)
    {
        score += distance * multiplier;
        UpdateScoreText();
    }

    public void IncreaseMultiplier()
    {
        multiplier *= 2.0f;
    }

    public void KarakteriHizlandir()
    {
        // Her 100 art��ta h�zland�r
        if (Convert.ToInt32(scoreText.text) < 2000)
        {
            characterMove.FwSpeed += (characterMove.FwSpeed / 100) * 5;
        }
    }
        
    
    public void UpdateBestScore()
    {
        if (score > bestScore)
        {
            bestScore = score;
            PlayerPrefs.SetFloat("BestScore", bestScore);
            UpdateBestScoreText();
        }
    }
}
