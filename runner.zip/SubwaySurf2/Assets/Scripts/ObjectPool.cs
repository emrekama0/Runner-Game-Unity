using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
   
        public Transform player; // Oyuncu karakterin transform bile�eni
        public GameObject mapPanelPrefab; // Harita paneli prefab�
        public int poolSize = 10; // Harita paneli havuzunun boyutu

        
        public List<GameObject> mapPanelPool; // Harita paneli havuzu
        public float panelLength = 103f; // Harita panelinin uzunlu�u
        public float spawnZ = 103f; // Harita panelinin spawn noktas�
        public float safeZone = -100f; // Yeni harita panelinin olu�turulaca�� nokta

        private void Start()
        {
           

            // �lk harita panelini olu�tur
            SpawnMapPanel();
        }

        private void Update()
        {
            // Oyuncunun konumunu kontrol et
            if (player.position.z - safeZone > spawnZ)
            {
                // Yeni bir harita paneli olu�tur
                SpawnMapPanel();
                DisablePanelBehindPlayer();
            }
        }

        private void SpawnMapPanel()
        {
            GameObject mapPanel = GetPooledMapPanel(); // Havuzdan bir harita paneli al

            mapPanel.transform.position = Vector3.forward * spawnZ; // Yeni harita panelini konumland�r
            mapPanel.SetActive(true); // Harita panelini etkinle�tir

            spawnZ += panelLength; // Yeni spawn noktas�n� g�ncelle
        }
    private void DisablePanelBehindPlayer()
    {
        // Oyuncunun konumundan 200 birim gerisindeki paneli bul
        float disableZ = player.position.z - 110f;

        for (int i = 0; i < poolSize; i++)
        {
            // Panelin konumunu kontrol et
            if (mapPanelPool[i].transform.position.z < disableZ)
            {
                // Panelin enabled �zelli�ini false yap
                mapPanelPool[i].SetActive(false);
            }
        }
    }
    private GameObject GetPooledMapPanel()
        {
        // Etkisiz harita panellerinin listesini olu�tur
        List<GameObject> inactivePanels = new List<GameObject>();

        // Havuzdaki etkisiz harita panellerini bul
        for (int i = 0; i < poolSize; i++)
        {
            if (!mapPanelPool[i].activeInHierarchy)
            {
                inactivePanels.Add(mapPanelPool[i]);
            }
        }

        // E�er etkisiz harita paneli bulunursa, rastgele birini se� ve d�nd�r
        if (inactivePanels.Count > 0)
        {
            int randomIndex = Random.Range(0, inactivePanels.Count);
            GameObject randomMapPanel = inactivePanels[randomIndex];
            return randomMapPanel;
        }

        // E�er etkisiz harita paneli bulunamazsa, rastgele bir harita panelini devre d��� b�rak�p kullan
        int randomIndexFallback = Random.Range(0, poolSize);
        GameObject randomMapPanelFallback = mapPanelPool[randomIndexFallback];
        randomMapPanelFallback.SetActive(false);
        return randomMapPanelFallback;
    }
    }

