using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class SceneController : MonoBehaviour
{
    public int kaydirkontr;
    public TMP_Text coinCount;
    public TMP_Text BestCount;
    public int yonkontrol;
    public Image YonTik;
    public GameObject SettingsPanel;
    // Start is called before the first frame update
    void Start()
    {
        
        PlayerPrefs.SetInt("yonkontrol", yonkontrol);
        int Coin = PlayerPrefs.GetInt("CoinCount");
        float Best = PlayerPrefs.GetFloat("BestScore");
        coinCount.text = Coin.ToString();
        BestCount.text = Best.ToString("F0")+" m";

    }

    public void Settings()
    {
        SettingsPanel.SetActive(true);
    }
    public void SettingsOff()
    {
        SettingsPanel.SetActive(false);
    }
    public void YonAktif()
    {
        yonkontrol = 1 - yonkontrol;
        PlayerPrefs.SetInt("yonkontrol", yonkontrol);
        PlayerPrefs.Save();

    }
    // Update is called once per frame
    void Update()
    {
        if(yonkontrol==1)
        {
            kaydirkontr = 0;
            PlayerPrefs.SetInt("kaydirkontrol", kaydirkontr);
            PlayerPrefs.Save();
            YonTik.enabled = true;
        }
        if (yonkontrol == 0)
        {
            kaydirkontr = 1;
            PlayerPrefs.SetInt("kaydirkontrol", kaydirkontr);
            PlayerPrefs.Save();
            YonTik.enabled = false;
        }
    }
    public void Basla()
    {
        SceneManager.LoadScene("SampleScene");
    }
}
