using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorLoop : MonoBehaviour
{
    private Animator animator;
    private readonly int animationHash = Animator.StringToHash("Base Layer.MyAnimation");
    private float animationTime = 0f;

    private void Start()
    {
        animator = GetComponent<Animator>();
    }

    private void OnEnable()
    {
        // Nesne etkinle�tirildi�inde, kaydedilen animasyon bilgilerini y�kle
        animator.Play(animationHash, -1, animationTime);
    }

    private void OnDisable()
    {
        // Nesne devre d��� b�rak�ld���nda, mevcut animasyon bilgilerini kaydet
        animationTime = animator.GetCurrentAnimatorStateInfo(0).normalizedTime;
    }

    private void Update()
    {
        // Nesne etkinle�tirilmi�se, animasyonu oynatmaya devam et
        if (isActiveAndEnabled)
        {
            animator.Play(animationHash, -1, animationTime);
        }
    }

}
