using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinRotation : MonoBehaviour
{
    public float rotationSpeed = 100f; // D�n�� h�z�
    private int rotationDirection; // D�n�� y�n�

    void Start()
    {
        // D�n�� y�n�n� rastgele belirle (-1 veya 1)
        rotationDirection = Random.Range(0, 2) * 2 - 1;
    }

    void Update()
    {
        // Coin'i y ekseni etraf�nda d�nd�r
        transform.Rotate(Vector3.up * rotationDirection * rotationSpeed * Time.deltaTime);
    }
}
