using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

[System.Serializable]

public enum SIDE { Left=-3, Mid=0, Right=3 }

public enum HitX { Left,Mid,Right,None}
public enum HitY { UP,Mid,Down,Low,None}
public enum HitZ { Forward, Mid, Backward, None}
public class CharMove : MonoBehaviour
{
    public SIDE m_Side = SIDE.Mid;

    [HideInInspector]
    public bool SwipeLeft,SwipeRight,SwipeUp,SwipeDown;
    public int Kaydirkontrolaktif;

    private CharacterController characterController;
    private Animator animator;

    public GameObject panel;
    private float x;
    public float SpeedDodge;

    public float JumpPower = 1f;
    private float y;
    public bool InJump;
    public bool InRoll;
    public float FwSpeed=7f;
    private float ColHeight;
    private float ColCenterY;
    public bool CanInput = true;

    public HitX hitX=HitX.None;
    public HitY hitY=HitY.None;
    public HitZ hitZ=HitZ.None;

   public SIDE LastSide;
    public bool StopAllState = false;
    
    public Collider CollisionCol;
    private float timer;
    public FollowGuard guard;
    private float curDistance = 0.6f;
    public bool Dead,hitmovingtrain;
    public Score score;
    private Vector2 initialTouchPosition;
    public CharSound charSound;

    private void Start()
    {
        Kaydirkontrolaktif=PlayerPrefs.GetInt("kaydirkontrol");
        characterController = GetComponent<CharacterController>();
        ColHeight = characterController.height;
        ColCenterY = characterController.center.y;
        animator = GetComponent<Animator>();
        transform.position = new Vector3(0f, 1f, 0f);
    }
    public void OnLeftButtonClicked()
    {
        if (m_Side == SIDE.Mid)
        {
            charSound.audioSource.PlayOneShot(charSound.z�pla);
            LastSide = m_Side;
            m_Side = SIDE.Left;
            if (InJump) return;
            PlayAnimation("dodgeLeft");
            guard.LeftDodge();
        }
        else if (m_Side == SIDE.Right)
        {
            charSound.audioSource.PlayOneShot(charSound.z�pla);
            LastSide = m_Side;
            m_Side = SIDE.Mid;
            if (InJump) return;
            PlayAnimation("dodgeLeft");
            guard.LeftDodge();
        }
        else if (m_Side != LastSide)
        {
            charSound.audioSource.PlayOneShot(charSound.stumble);
            LastSide = m_Side;
            PlayAnimation("stumbleOffLeft");
            guard.Stumble();
            curDistance = 0.6f;
        }
    }

    // Sa� butonun t�klama olay�
    public void OnRightButtonClicked()
    {
        if (CanInput)
        {
            if (m_Side == SIDE.Mid)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                LastSide = m_Side;
                m_Side = SIDE.Right;
                if (InJump) return;
                PlayAnimation("dodgeRight");
                guard.RightDodge();

            }
            else if (m_Side == SIDE.Left)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                LastSide = m_Side;
                m_Side = SIDE.Mid;
                if (InJump) return;
                PlayAnimation("dodgeRight");
                guard.RightDodge();
            }
            else if (m_Side != LastSide)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                LastSide = m_Side;
                PlayAnimation("stumbleOffRight");
                guard.Stumble();
                curDistance = 0.6f;
            }
        }
    }

    // Yukar� butonun t�klama olay�
    public void OnUpButtonClicked()
    {
        if(characterController.isGrounded)
        {
            charSound.audioSource.PlayOneShot(charSound.z�pla);
            y = JumpPower;
            animator.CrossFadeInFixedTime("Jump", 0.1f);
            guard.Jump();
            InJump = true;
        }
    }

    // A�a�� butonun t�klama olay�
    public void OnDownButtonClicked()
    {
        RollCounter = 0.5f;
        y -= 10f;
        characterController.center = new Vector3(0, ColCenterY / 2f, 0);
        characterController.height = ColHeight / 2f;
        animator.CrossFadeInFixedTime("roll", 0.1f);
        InRoll = true;
        InJump = false;
        charSound.audioSource.PlayOneShot(charSound.z�pla);
    }


    void Update()
    {
        guard.curDis = curDistance;
        CollisionCol.isTrigger = !CanInput;
        if (Dead)
        {
            if (curDistance < 3f)
            {
                curDistance = Mathf.MoveTowards(curDistance, 0.0f, Time.deltaTime * 5f);////
                guard.Follow(transform.position, FwSpeed);//Fwspeed
                if (hitmovingtrain)
                {
                    guard.HitMovingTrain();
                    return;
                }
                guard.CaughtPlayer();
                animator.Play("caught1");
            }
        }
        if (!CanInput)
        {
            characterController.Move(Vector3.down * 10f * Time.deltaTime);
            return;
        }
        if (Kaydirkontrolaktif == 1)
        {
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);

                if (touch.phase == TouchPhase.Began)
                {
                    initialTouchPosition = touch.position;
                }
                else if (touch.phase == TouchPhase.Ended)
                {
                    Vector2 dragDirection = touch.position - initialTouchPosition;
                    float dragDistance = dragDirection.magnitude;

                    if (dragDistance > 0)
                    {
                        dragDirection.Normalize();

                        if (Mathf.Abs(dragDirection.x) > Mathf.Abs(dragDirection.y))
                        {
                            if (dragDirection.x > 0)
                            {
                                Debug.Log("Right");
                                if (CanInput)
                                {
                                    if (m_Side == SIDE.Mid)
                                    {
                                        charSound.audioSource.PlayOneShot(charSound.z�pla);
                                        LastSide = m_Side;
                                        m_Side = SIDE.Right;
                                        if (InJump) return;
                                        PlayAnimation("dodgeRight");
                                        guard.RightDodge();

                                    }
                                    else if (m_Side == SIDE.Left)
                                    {
                                        charSound.audioSource.PlayOneShot(charSound.z�pla);
                                        LastSide = m_Side;
                                        m_Side = SIDE.Mid;
                                        if (InJump) return;
                                        PlayAnimation("dodgeRight");
                                        guard.RightDodge();
                                    }
                                    else if (m_Side != LastSide)
                                    {
                                        charSound.audioSource.PlayOneShot(charSound.stumble);
                                        LastSide = m_Side;
                                        PlayAnimation("stumbleOffRight");
                                        guard.Stumble();
                                        curDistance = 0.6f;
                                    }
                                }
                            }
                            else
                            {
                                Debug.Log("Left");
                                if (m_Side == SIDE.Mid)
                                {
                                    charSound.audioSource.PlayOneShot(charSound.z�pla);
                                    LastSide = m_Side;
                                    m_Side = SIDE.Left;
                                    if (InJump) return;
                                    PlayAnimation("dodgeLeft");
                                    guard.LeftDodge();
                                }
                                else if (m_Side == SIDE.Right)
                                {
                                    charSound.audioSource.PlayOneShot(charSound.z�pla);
                                    LastSide = m_Side;
                                    m_Side = SIDE.Mid;
                                    if (InJump) return;
                                    PlayAnimation("dodgeLeft");
                                    guard.LeftDodge();
                                }
                                else if (m_Side != LastSide)
                                {
                                    charSound.audioSource.PlayOneShot(charSound.stumble);
                                    LastSide = m_Side;
                                    PlayAnimation("stumbleOffLeft");
                                    guard.Stumble();
                                    curDistance = 0.6f;
                                }
                            }
                        }
                        else
                        {
                            if (dragDirection.y > 0 && characterController.isGrounded)
                            {
                                Debug.Log("Up");
                                charSound.audioSource.PlayOneShot(charSound.z�pla);
                                y = JumpPower;
                                animator.CrossFadeInFixedTime("Jump", 0.1f);
                                guard.Jump();
                                InJump = true;
                            }
                            else
                            {
                                Debug.Log("Down");
                                RollCounter = 0.5f;
                                y -= 10f;
                                charSound.audioSource.PlayOneShot(charSound.z�pla);
                                characterController.center = new Vector3(0, ColCenterY / 2f, 0);
                                characterController.height = ColHeight / 2f;
                                animator.CrossFadeInFixedTime("roll", 0.1f);
                                InRoll = true;
                                InJump = false;
                            }
                        }
                    }
                }
            }
        }
        SwipeLeft = (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow)) && CanInput;
        SwipeRight = (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow)) && CanInput;
        SwipeUp = (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) && CanInput;
        SwipeDown = (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow)) && CanInput;

        if (SwipeLeft)
        {
            if(m_Side==SIDE.Mid)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                LastSide = m_Side;
                m_Side = SIDE.Left;
                if (InJump) return;
                PlayAnimation("dodgeLeft");
                guard.LeftDodge();
            }
            else if(m_Side==SIDE.Right)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                LastSide = m_Side;
                m_Side = SIDE.Mid;
                if (InJump) return;
                PlayAnimation("dodgeLeft");
                guard.LeftDodge();
            }
            else if(m_Side != LastSide)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                LastSide = m_Side;
                PlayAnimation("stumbleOffLeft");
                guard.Stumble();
                curDistance = 0.6f;
            }
        }
        else if (SwipeRight)
        {
            if (m_Side == SIDE.Mid)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                LastSide = m_Side;
                m_Side = SIDE.Right;
                if (InJump) return;
                PlayAnimation("dodgeRight");
                guard.RightDodge();

            }
            else if (m_Side == SIDE.Left)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                LastSide = m_Side;
                m_Side = SIDE.Mid;
                if (InJump) return;
                PlayAnimation("dodgeRight");
                guard.RightDodge();
            }
            else if(m_Side!=LastSide)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                LastSide = m_Side;
                PlayAnimation("stumbleOffRight");
                guard.Stumble();
                curDistance = 0.6f;
            }
        }
        curDistance = Mathf.MoveTowards(curDistance, 5f, Time.deltaTime*0.1f);
        guard.Follow(transform.position, FwSpeed ); ;//fwspeed
        timer = Mathf.MoveTowards(timer, 0.0f, Time.deltaTime);
        if(timer <= 0.0f)
        {
            animator.SetLayerWeight(1, 0);
            StopAllState = false;
        }

        
        Vector3 moveVector = new Vector3(x - transform.position.x, y*Time.deltaTime, FwSpeed);
        x = Mathf.Lerp(x, (int)m_Side, Time.deltaTime * SpeedDodge);
        characterController.Move(moveVector);
        Jump();
        Roll();
    }
    
    public IEnumerator DeathPlayer(string anim)
    {
        charSound.audioSource.PlayOneShot(charSound.carp);
        Dead = true;
        StopAllState = true;
        animator.SetLayerWeight(1, 0);
        animator.Play(anim);
        yield return new WaitForSeconds(0.2f);
        CanInput = false;
        curDistance = 0.0f;
        score.UpdateBestScore();
        yield return new WaitForSeconds(3f);
        panel.SetActive(true);
    }
    public void PlayAnimation(string anim)
    {
        if (StopAllState||Dead) return;
        animator.Play(anim);
    }

    public void Stumble(string anim,int layer)
    {
       
        StopAllState = true;
        animator.Play(anim);
        timer = animator.GetCurrentAnimatorStateInfo(layer).length;
        if(curDistance<3f)
        {
            StartCoroutine(DeathPlayer("stumbleFall"));
            return;
        }
        curDistance = 0.6f;
        ResetCollision();
    }
    public void Jump()
    {
        if(characterController.isGrounded)
        {
            
            if(animator.GetCurrentAnimatorStateInfo(0).IsName("Falling"))
            {
                PlayAnimation("Landing");
                InJump = false;
            }
            if(SwipeUp)
            {
                charSound.audioSource.PlayOneShot(charSound.z�pla);
                y = JumpPower;
                animator.CrossFadeInFixedTime("Jump", 0.1f);
                guard.Jump();
                InJump = true;
            }
        }
        else
        {
            y -= JumpPower * 2 * Time.deltaTime;
            if((characterController.velocity.y<-0.1f))
            PlayAnimation("Falling");
        }
    }
    internal float RollCounter;
    public void Roll()
    {
        RollCounter -= Time.deltaTime;
        if(RollCounter <=0f)
        {
            RollCounter = 0f;
            characterController.center = new Vector3(0, ColCenterY, 0);
            characterController.height = ColHeight;
            InRoll = false;
        }
        if(SwipeDown)
        {
            RollCounter = 0.5f;
            y -= 10f;
            characterController.center = new Vector3(0, ColCenterY/2f, 0);
            characterController.height = ColHeight/2f;
            animator.CrossFadeInFixedTime("roll", 0.1f);
            InRoll = true;
            InJump = false;
        }
    }

    public void OnCharacterColliderHit(Collider col)
    {
        hitX = GetHitX(col);
        hitY = GetHitY(col);
        hitZ = GetHitZ(col);
        if(hitZ==HitZ.Forward && hitX==HitX.Mid)//Death
        {
            if (hitY == HitY.Low)
            {
                Stumble("stumble_low",0);
                charSound.audioSource.PlayOneShot(charSound.stumble);
            }
            else if (hitY == HitY.Down)
            {
                StartCoroutine(DeathPlayer("death_lower"));
                
                
            }
            else if (hitY == HitY.Mid)
            {
                if (col.tag == "MovingTrain")
                {
                    StartCoroutine(DeathPlayer("death_movingTrain"));
                    hitmovingtrain = true;


                }
                else if (col.tag != "Ramp")
                {
                    StartCoroutine(DeathPlayer("death_bounce"));
                    
                    
                }
            }
            else if (hitY == HitY.UP && !InRoll)
            {
                StartCoroutine(DeathPlayer("death_upper"));
                
                
            }
        }else if(hitZ==HitZ.Mid)
        {
            if(hitX==HitX.Right)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                Debug.Log("Duvar");
                m_Side = LastSide;
                Stumble("stumbleSideRight",0);
                
            }
            if (hitX == HitX.Left)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                Debug.Log("Duvar");
                m_Side = LastSide;
                Stumble("stumbleSideLeft",0);
                
            }

        }else
        {
            if (hitX == HitX.Right)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                animator.SetLayerWeight(1,1);
                Stumble("stumbleCornerRight",1);
               
            }
            if (hitX == HitX.Left)
            {
                charSound.audioSource.PlayOneShot(charSound.stumble);
                animator.SetLayerWeight(1, 1);
                Stumble("stumbleCornerLeft",1);
                
            }
        }
    }
    public HitX GetHitX(Collider col)
    {
        Bounds char_bounds = characterController.bounds;
        Bounds col_bounds = col.bounds;
        float min_x = Mathf.Max(col_bounds.min.x, char_bounds.min.x);
        float max_x = Mathf.Min(col_bounds.max.x, char_bounds.max.x);
        float average = (min_x + max_x) / 2f - col_bounds.min.x;
        HitX hit;
        if (average > col_bounds.size.x - 0.33f)
            hit = HitX.Right;
        else if (average < 0.33f)
            hit = HitX.Left;
        else
            hit = HitX.Mid;
        return hit;
    }

    private void ResetCollision()
    {
       
        print(hitX.ToString() + hitY.ToString() + hitZ.ToString());
        hitX = HitX.None;
        hitY = HitY.None;
        hitZ = HitZ.None;
    }
    public HitY GetHitY(Collider col)
    {
        Bounds char_bounds = characterController.bounds;
        Bounds col_bounds = col.bounds;
        float min_y = Mathf.Max(col_bounds.min.y, char_bounds.min.y);
        float max_y = Mathf.Min(col_bounds.max.y, char_bounds.max.y);
        float average = ((min_y + max_y) / 2f - char_bounds.min.y) / char_bounds.size.y;
        HitY hit;
        if (average < 0.17f)
            hit = HitY.Low;
        else if (average < 0.33f)
            hit = HitY.Down;
        else if (average < 0.66f)
            hit = HitY.Mid;
        else
            hit = HitY.UP;
        return hit;
    }

    public HitZ GetHitZ(Collider col)
    {
        Bounds char_bounds = characterController.bounds;
        Bounds col_bounds = col.bounds;
        float min_z = Mathf.Max(col_bounds.min.z, char_bounds.min.z);
        float max_z = Mathf.Min(col_bounds.max.z, char_bounds.max.z);
        float average = ((min_z + max_z) / 2f - char_bounds.min.z) / char_bounds.size.z;
        HitZ hit;
        if (average < 0.33f)
            hit = HitZ.Backward;
        else if (average < 0.66f)
            hit = HitZ.Mid;
        else
            hit = HitZ.Forward;
        return hit;
    }
}
